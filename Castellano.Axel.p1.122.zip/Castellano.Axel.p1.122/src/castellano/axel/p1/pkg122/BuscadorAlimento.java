package castellano.axel.p1.pkg122;

public interface BuscadorAlimento {

    void buscarAlimento();
}
