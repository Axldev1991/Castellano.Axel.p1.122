package castellano.axel.p1.pkg122;

public class CastellanoAxelP1122 {

    public static void main(String[] args) {

        Acuario aquarius = new Acuario("Acuario Seco");

        Pez p1 = new Pez("Nemo", "Tanque tropical", 10, TipoAgua.SALADA);
        Pez p2 = new Pez("Nemo", "Tanque tropical", 10, TipoAgua.DULCE);
        Pez p3 = new Pez("Esturion", "Tanque artico", 10, TipoAgua.SALADA);

        MamiferoMarino m1 = new MamiferoMarino("Ballena", "Tanque de guerra", 10, TipoAgua.DULCE);
        MamiferoMarino m2 = new MamiferoMarino("Morsa", "Tanque de guerra", 10, TipoAgua.DULCE);
        MamiferoMarino m3 = new MamiferoMarino("Delfin", "Tanque tropical", 10, TipoAgua.SALADA);

        Crustaceo c1 = new Crustaceo("krusty 10", "Tanque oxigeno liquido", 10, TipoAgua.SALADA);
        Crustaceo c2 = new Crustaceo("krusto 20", "Tanque tropical", 10, TipoAgua.SALADA);
        Crustaceo c3 = new Crustaceo("krusta 30", "Tanque artico", 10, TipoAgua.DULCE);

        System.out.println("AGREGANDO ANIMALES AL SISTEMA");
        aquarius.agregarAnimal(p1);

        //Intentamos agregar un animal repetido
        try {
            aquarius.agregarAnimal(p2);
        } catch (NullPointerException | AnimalExistenteException ex) {
            System.out.println(ex.getMessage());
        }

        aquarius.agregarAnimal(p3);

        aquarius.agregarAnimal(m1);
        aquarius.agregarAnimal(m2);
        aquarius.agregarAnimal(m3);

        aquarius.agregarAnimal(c1);
        aquarius.agregarAnimal(c2);
        aquarius.agregarAnimal(c3);
        System.out.println("--------------------------\n");

        System.out.println("MOSTRANDO LA LISTA DE TODOS LOS ANIMALES");
        aquarius.mostrarAnimales();
        System.out.println("--------------------------\n");

        System.out.println("LLAMANDO A LOS METODOS DE LAS INTERFACES");
        aquarius.buscarAlimento();
        aquarius.nadar();
        System.out.println("--------------------------\n");

        System.out.println("TIPO AGUA - FILTRADO");
        aquarius.filtrarPorTipoAgua(TipoAgua.DULCE);
        System.out.println("--------------------------\n");

        System.out.println("TIPO ANIMAL - FILTRADO");
        aquarius.mostrarAnimalesPorTipo("Crustaceo");
        System.out.println("--------------------------\n");
    }
}
