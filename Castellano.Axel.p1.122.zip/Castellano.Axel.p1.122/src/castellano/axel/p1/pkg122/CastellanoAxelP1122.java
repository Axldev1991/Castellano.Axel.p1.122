package castellano.axel.p1.pkg122;

public class CastellanoAxelP1122 {

    public static void main(String[] args) {

        Acuario aquarius = new Acuario("Acuario Seco");

        Pez p1 = new Pez(10, "Nemo", "Tanque tropical", TipoAgua.SALADA);
        Pez p2 = new Pez(10, "Nemo", "Tanque tropical", TipoAgua.DULCE);
        Pez p3 = new Pez(10, "Esturion", "Tanque artico", TipoAgua.SALADA);

        MamiferoMarino m1 = new MamiferoMarino("Ballena", "Tanque deguerra", TipoAgua.DULCE);
        MamiferoMarino m2 = new MamiferoMarino("Morsa", "Tanque deguerra", TipoAgua.DULCE);
        MamiferoMarino m3 = new MamiferoMarino("Delfin", "Tanque tropical", TipoAgua.SALADA);

        Crustaceo c1 = new Crustaceo(6, "krusty 10", "Tanque oxigenoliquido", TipoAgua.SALADA);
        Crustaceo c2 = new Crustaceo(8, "krusto 20", "Tanque tropical", TipoAgua.SALADA);
        Crustaceo c3 = new Crustaceo(20, "krusta 30", "Tanque artico", TipoAgua.DULCE);

        System.out.println("AGREGANDO ANIMALES AL SISTEMA");
        aquarius.agregarAnimal(p1);
        aquarius.agregarAnimal(p2);
        aquarius.agregarAnimal(p3);

        aquarius.agregarAnimal(m1);
        aquarius.agregarAnimal(m2);
        aquarius.agregarAnimal(m3);

        aquarius.agregarAnimal(c1);
        aquarius.agregarAnimal(c2);
        aquarius.agregarAnimal(c3);
        System.out.println("--------------------------\n");

        System.out.println("MOSTRANDO LA LISTA DE TODOS LOS ANIMALES");
        aquarius.mostrarAnimales();
        System.out.println("--------------------------\n");

        System.out.println("LLAMANDO A LOS METODOS DE LAS INTERFACES");
        aquarius.buscarAlimento();
        aquarius.nadar();
        System.out.println("--------------------------\n");

        System.out.println("TIPO AGUA - FILTRADO");
        aquarius.filtrarPorTipoAgua(TipoAgua.DULCE);
        System.out.println("--------------------------\n");

        System.out.println("TIPO ANIMAL - FILTRADO");
        aquarius.mostrarAnimalesPorTipo("Crustaceo");
        System.out.println("--------------------------\n");
    }
}
