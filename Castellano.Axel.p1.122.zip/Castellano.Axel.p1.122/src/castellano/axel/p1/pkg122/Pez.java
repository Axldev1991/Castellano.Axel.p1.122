package castellano.axel.p1.pkg122;

import java.util.Objects;

public class Pez extends Animal implements Nadador {

    private double longitudMaxima;

    public Pez(double longitudMaxima, String nombre, String habitatAcuario, TipoAgua tipoAgua) {
        super(nombre, habitatAcuario, tipoAgua);
        this.longitudMaxima = longitudMaxima;
    }

    public double getLongitudMaxima() {
        return longitudMaxima;
    }

    @Override
    public void nadar() {
        System.out.println("Soy " + this.getNombre() + " un pez y me mandaron a nadar...");
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(longitudMaxima);
    }

    @Override
    public boolean equals(Object o) {
        if (!super.equals(o)) {
            return false;
        }

        Pez p = (Pez) o;
        return p.getLongitudMaxima() == this.longitudMaxima;
    }

    @Override
    public String toString() {
        String base = super.toString();

        StringBuilder sb = new StringBuilder(base);
        sb.insert(sb.length() - 1, ", longitudMaxima=" + longitudMaxima);

        return sb.toString();
    }

}
