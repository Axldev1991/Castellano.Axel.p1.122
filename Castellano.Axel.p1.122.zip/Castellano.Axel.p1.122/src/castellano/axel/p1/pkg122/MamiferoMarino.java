package castellano.axel.p1.pkg122;

import java.util.Objects;

public class MamiferoMarino extends Animal implements Nadador, BuscadorAlimento {

    private double frecuenciaRespiracion;

    public MamiferoMarino(String nombre, String habitatAcuario, double frecuenciaRespiracion, TipoAgua tipoAgua) {
        super(nombre, habitatAcuario, tipoAgua);
        this.frecuenciaRespiracion = frecuenciaRespiracion;
    }

    public double getFrecuenciaRespiracion() {
        return frecuenciaRespiracion;
    }

    @Override
    public void nadar() {
        System.out.println("Soy " + this.getNombre() + " un mamifero marino y nado con mis aletas!");
    }

    @Override
    public void buscarAlimento() {
        System.out.println("Soy " + this.getNombre() + " un mamifero marino y me voy porque tengo hambre !!!");
    }

//    @Override
//    public int hashCode() {
//        return Objects.hash(frecuenciaRespiracion);
//    }
//
//    @Override
//    public boolean equals(Object o) {
//        if (!super.equals(o)) {
//            return false;
//        }
//
//        MamiferoMarino m = (MamiferoMarino) o;
//        return m.getFrecuenciaRespiracion()== this.frecuenciaRespiracion;
//    }
    @Override
    public String toString() {
        String base = super.toString();

        StringBuilder sb = new StringBuilder(base);
        sb.insert(sb.length() - 1, ", frecuenciaRespiracion=" + frecuenciaRespiracion);

        return sb.toString();
    }

}
