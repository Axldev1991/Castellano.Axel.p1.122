package castellano.axel.p1.pkg122;

public enum TipoAgua {
    DULCE,
    SALADA
}
