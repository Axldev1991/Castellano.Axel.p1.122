package castellano.axel.p1.pkg122;

import java.util.Objects;

public abstract class Animal {

    private String nombre;
    private String habitatAcuario;
    private TipoAgua tipoAgua;

    public Animal(String nombre, String habitatAcuario, TipoAgua tipoAgua) {
        this.nombre = nombre;
        this.habitatAcuario = habitatAcuario;
        this.tipoAgua = tipoAgua;
    }

    public String getNombre() {
        return nombre;
    }

    public String getHabitatAcuario() {
        return habitatAcuario;
    }

    public TipoAgua getTipoAgua() {
        return tipoAgua;
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, habitatAcuario, tipoAgua);
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || o.getClass() != this.getClass()) {
            return false;
        }

        Animal a = (Animal) o;
        return a.getNombre().equals(this.nombre) && a.getHabitatAcuario().equals(this.habitatAcuario);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{nombre=" + nombre);
        sb.append(", habitatAcuario=" + habitatAcuario);
        sb.append(", tipoAgua=" + tipoAgua);
        sb.append("}");
        return sb.toString();
    }

}
