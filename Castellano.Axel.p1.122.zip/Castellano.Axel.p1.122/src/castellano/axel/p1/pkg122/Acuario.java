package castellano.axel.p1.pkg122;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Acuario {

    private String nombre;
    private List<Animal> listaAnimales;

    public Acuario() {
        this.listaAnimales = new ArrayList<>();
    }

    public Acuario(String nombre) {
        this();
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void agregarAnimal(Animal animal) {
        try {
            validarAnimalNull(animal);
            validarAnimalRepetido(animal);
            listaAnimales.add(animal);
        } catch (NullPointerException | AnimalExistenteException e) {
            System.out.println(e.getMessage());
        }
    }

    private void validarAnimalNull(Animal animal) {
        if (animal == null) {
            throw new NullPointerException("ERROR - Animal null");
        }
    }

    private void validarAnimalRepetido(Animal animal) throws AnimalExistenteException {
        for (Animal a : listaAnimales) {
            if (a.equals(animal)) {
                throw new AnimalExistenteException();
            }
        }
    }

    public void mostrarAnimales() {
        for (Animal a : listaAnimales) {
            System.out.println(a.toString());
        }
    }

    public void nadar() {
        for (Animal a : listaAnimales) {
            if (a instanceof Nadador nad) {
                nad.nadar();
            } else {
                System.out.println("Yo " + a.getNombre() + " soy un Crustaceo y NO PUEDO nadar...");
            }
        }
    }

    public void buscarAlimento() {
        for (Animal a : listaAnimales) {
            if (a instanceof BuscadorAlimento bus) {
                bus.buscarAlimento();
            } else {
                System.out.println("Yo " + a.getNombre() + " soy un Pez y NO PUEDO buscar alimento");
            }
        }
    }

    public ArrayList filtrarPorTipoAgua(TipoAgua tipo) {
        ArrayList<Animal> listaNueva = new ArrayList<>();
        for (Animal a : listaAnimales) {
            if (a.getTipoAgua().equals(tipo)) {
                System.out.println(a.toString());
                listaNueva.add(a);
            }
        }
        return listaNueva;
    }

    public void mostrarAnimalesPorTipo(String tipoAnimal) {
        for (Animal a : listaAnimales) {
            if (a.getClass().getSimpleName().equals(tipoAnimal)) {
                System.out.println(a.toString());
            }
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre);
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || o.getClass() != this.getClass()) {
            return false;
        }

        Acuario a = (Acuario) o;
        return a.getNombre().equals(this.nombre);
    }

    @Override
    public String toString() {
        return "Acuario{" + "nombre=" + nombre + '}';
    }

}
