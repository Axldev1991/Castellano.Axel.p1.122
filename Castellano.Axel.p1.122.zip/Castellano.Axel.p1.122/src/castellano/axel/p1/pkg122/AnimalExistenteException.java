package castellano.axel.p1.pkg122;

public class AnimalExistenteException extends Exception {

    private final static String MESSAGE = "Especie repetida.";

    public AnimalExistenteException() {
        this(MESSAGE);
    }

    public AnimalExistenteException(String message) {
        super(message);
    }

}
