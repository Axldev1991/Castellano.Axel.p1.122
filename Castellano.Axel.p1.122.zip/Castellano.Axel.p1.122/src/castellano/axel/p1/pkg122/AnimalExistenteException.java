package castellano.axel.p1.pkg122;

public class AnimalExistenteException extends RuntimeException {

    private final static String MESSAGE = "Especie repetida.";

    public AnimalExistenteException() {
        this(MESSAGE);
    }

    public AnimalExistenteException(String message) {
        super(message);
    }

}
