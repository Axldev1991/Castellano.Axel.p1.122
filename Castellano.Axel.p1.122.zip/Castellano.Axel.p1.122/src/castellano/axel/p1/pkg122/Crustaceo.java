package castellano.axel.p1.pkg122;

import java.util.Objects;

public class Crustaceo extends Animal implements BuscadorAlimento {

    private int numeroDePatas;

    public Crustaceo(int numeroDePatas, String nombre, String habitatAcuario, TipoAgua tipoAgua) {
        super(nombre, habitatAcuario, tipoAgua);
        this.numeroDePatas = numeroDePatas;
    }

    public int getNumeroDePatas() {
        return numeroDePatas;
    }

    @Override
    public void buscarAlimento() {
        System.out.println("Soy " + this.getNombre() + " un crustaceo y estoy comiendo ASADO");
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(numeroDePatas);
    }

    @Override
    public boolean equals(Object o) {
        if (!super.equals(o)) {
            return false;
        }

        Crustaceo c = (Crustaceo) o;
        return c.getNumeroDePatas() == this.numeroDePatas;
    }

    @Override
    public String toString() {
        String base = super.toString();

        StringBuilder sb = new StringBuilder(base);
        sb.insert(sb.length() - 1, ", numeroDePatas=" + numeroDePatas);

        return sb.toString();
    }

    
    
    
}
