package castellano.axel.rec1.pkg122;

public class AstroExistenteException extends RuntimeException {

    private final static String MESSAGE = "Astro existente - repetido.";

    public AstroExistenteException() {
        this(MESSAGE);
    }

    public AstroExistenteException(String message) {
        super(message);
    }
}
