package castellano.axel.rec1.pkg122;

public interface ModificadorDeOrbita {

    void modificarOrbita();

}
