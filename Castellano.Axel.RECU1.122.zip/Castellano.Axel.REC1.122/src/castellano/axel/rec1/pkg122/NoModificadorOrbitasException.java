package castellano.axel.rec1.pkg122;

public class NoModificadorOrbitasException extends Exception {

    private final static String MESSAGE = "El objeto no es modificador de orbitas.";

    public NoModificadorOrbitasException() {
        this(MESSAGE);
    }

    public NoModificadorOrbitasException(String message) {
        super(message);
    }
}
