package castellano.axel.rec1.pkg122;

public class CastellanoAxelREC1122 {

    public static void main(String[] args){
        GestorAstros observatorio = new GestorAstros();

        Estrella e0 = null;
        Estrella e1 = new Estrella("Estrella X001", "Orion", TipoRadiacion.RAYOS_X, -273);
        Estrella e11 = new Estrella("Estrella X001", "Orion", TipoRadiacion.RAYOS_X, -273);
        Estrella e2 = new Estrella("Estrella X002", "Sagitario A*", TipoRadiacion.INFRARROJA, 25);
        Estrella e3 = new Estrella("Estrella X003", "Nebulosa", TipoRadiacion.ULTRAVIOLETA, -42);

        Planeta p1 = new Planeta("Marte", "Via Lactea", TipoRadiacion.ULTRAVIOLETA, false);
        Planeta p2 = new Planeta("Tierra", "Via Lactea", TipoRadiacion.RAYOS_X, true);
        Planeta p3 = new Planeta("Mercurio", "Via Lactea", TipoRadiacion.INFRARROJA, false);
        Planeta p4 = new Planeta("Jupiter", "Via Lactea", TipoRadiacion.INFRARROJA, true);

        Cometa c1 = new Cometa("Haley", "farfaraway", TipoRadiacion.ULTRAVIOLETA, 12);
        Cometa c2 = new Cometa("C571", "atmosfera terrestre", TipoRadiacion.RAYOS_X, 2);
        Cometa c3 = new Cometa("C572", "nebulosa", TipoRadiacion.ULTRAVIOLETA, 98);
        Cometa c4 = new Cometa("C573", "infitino y más allá", TipoRadiacion.RAYOS_X, 5);

        observatorio.agregarAstro(e1);
        observatorio.agregarAstro(e2);
        observatorio.agregarAstro(e3);

        //intentamos agregar un planeta existente y uno nulo
        try {
            observatorio.agregarAstro(e11);
        } catch (AstroExistenteException e) {
            System.out.println(e.getMessage());
        }

        try {
            observatorio.agregarAstro(e0);
        } catch (AstroNuloException e) {
            System.out.println(e.getMessage());
        }

        observatorio.agregarAstro(p1);
        observatorio.agregarAstro(p2);
        observatorio.agregarAstro(p3);
        observatorio.agregarAstro(p4);

        observatorio.agregarAstro(c1);
        observatorio.agregarAstro(c2);
        observatorio.agregarAstro(c3);
        observatorio.agregarAstro(c4);

        System.out.println("----LISTA DE ASTROS----");
        observatorio.mostrarAstros();
        System.out.println("\n\n\n");

        System.out.println("----LLAMAMOS A LOS ASTROS GENERADORES----");
        observatorio.generarCamposMagneticos();
        System.out.println("\n\n\n");

        System.out.println("----LLAMAMOS A LOS ASTROS MODIFICADORES----");
        observatorio.modificarOrbitas();
        System.out.println("\n\n\n");

        System.out.println("----FILTRAMOS POR TIPO RADIACION----");
        observatorio.filtrarPorTipoRadiacion(TipoRadiacion.RAYOS_X);
        System.out.println("\n");

        observatorio.filtrarPorTipoRadiacion(TipoRadiacion.INFRARROJA);
        System.out.println("\n");

        observatorio.filtrarPorTipoRadiacion(TipoRadiacion.ULTRAVIOLETA);
        System.out.println("\n\n\n");

        System.out.println("----FILTRAMOS POR TIPO DE ASTRO----");
        observatorio.filtrarPorTipoDeAstro("Estrella");
        System.out.println("\n");

        observatorio.filtrarPorTipoDeAstro("Planeta");
        System.out.println("\n");

        observatorio.filtrarPorTipoDeAstro("Cometa");
        System.out.println("\n\n\n");

    }

}
