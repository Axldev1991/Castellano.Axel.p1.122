package castellano.axel.rec1.pkg122;

public class Planeta extends Astro implements GeneradorDeCampo {

    private boolean tieneAtmosfera;

    public Planeta(String nombreIdentificador, String region, TipoRadiacion tipo, boolean tieneAtmosfera) {
        super(nombreIdentificador, region, tipo);
        this.tieneAtmosfera = tieneAtmosfera;
    }

    @Override
    public void generarCampoMagnetico() {
        System.out.println("El PLANETA " + getNombreIdentificador() + " está generando un campo magnético.");
    }
    
    @Override
    public String toString() {
        String base = super.toString();

        StringBuilder sb = new StringBuilder(base);
        sb.insert(sb.length() - 1, ", tieneAtmosfera=" + tieneAtmosfera);

        return sb.toString();
    }
}
