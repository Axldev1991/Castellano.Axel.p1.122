package castellano.axel.rec1.pkg122;

public class NoGeneradorException extends Exception {

    private final static String MESSAGE = "El objeto no puede generar un campo.";

    public NoGeneradorException() {
        this(MESSAGE);
    }

    public NoGeneradorException(String message) {
        super(message);
    }
}
