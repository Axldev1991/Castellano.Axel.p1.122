package castellano.axel.rec1.pkg122;

public class AstroNuloException extends RuntimeException {

    private final static String MESSAGE = "Objeto (Astro) nulo.";

    public AstroNuloException() {
        this(MESSAGE);
    }

    public AstroNuloException(String message) {
        super(message);
    }
}
