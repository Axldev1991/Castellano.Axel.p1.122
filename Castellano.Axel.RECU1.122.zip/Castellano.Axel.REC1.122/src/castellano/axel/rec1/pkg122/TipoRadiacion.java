package castellano.axel.rec1.pkg122;

public enum TipoRadiacion {
    INFRARROJA, ULTRAVIOLETA, RAYOS_X
}
