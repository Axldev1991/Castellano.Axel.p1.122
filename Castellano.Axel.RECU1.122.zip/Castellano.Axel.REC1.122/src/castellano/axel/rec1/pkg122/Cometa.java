package castellano.axel.rec1.pkg122;

public class Cometa extends Astro implements ModificadorDeOrbita {

    private int periodoOrbital;

    public Cometa(String nombreIdentificador, String region, TipoRadiacion tipo, int periodoOrbital) {
        super(nombreIdentificador, region, tipo);
        this.periodoOrbital = periodoOrbital;
    }

    @Override
    public void modificarOrbita() {
        System.out.println("El COMETA " + getNombreIdentificador() + " modifica su orbita.");
    }
    
    @Override
    public String toString() {
        String base = super.toString();

        StringBuilder sb = new StringBuilder(base);
        sb.insert(sb.length() - 1, ", periodoOrbital=" + periodoOrbital);

        return sb.toString();
    }

}
