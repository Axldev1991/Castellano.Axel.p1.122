package castellano.axel.rec1.pkg122;

import java.util.Objects;

public abstract class Astro {

    private String nombreIdentificador;
    private String region;
    private TipoRadiacion tipo;

    public Astro(String nombreIdentificador, String region, TipoRadiacion tipo) {
        this.nombreIdentificador = nombreIdentificador;
        this.region = region;
        this.tipo = tipo;
    }

    public String getNombreIdentificador() {
        return nombreIdentificador;
    }

    public String getRegion() {
        return region;
    }

    public TipoRadiacion getTipo() {
        return tipo;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 73 * hash + Objects.hashCode(this.nombreIdentificador);
        hash = 73 * hash + Objects.hashCode(this.region);
        return hash;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || o.getClass() != this.getClass()) {
            return false;
        }

        Astro a = (Astro) o;
        return a.getNombreIdentificador().equals(this.nombreIdentificador) && a.getRegion().equals(this.region);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Astro{");
        sb.append("nombreIdentificador=").append(nombreIdentificador);
        sb.append(", region=").append(region);
        sb.append(", tipo=").append(tipo);
        sb.append('}');
        return sb.toString();
    }

}
