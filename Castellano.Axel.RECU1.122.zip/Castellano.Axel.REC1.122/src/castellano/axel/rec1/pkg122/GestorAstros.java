package castellano.axel.rec1.pkg122;

import java.util.ArrayList;
import java.util.List;

public class GestorAstros {

    private List<Astro> listaAstros;

    public GestorAstros() {
        this.listaAstros = new ArrayList<>();
    }

    public void agregarAstro(Astro a) {
        validarAstroNulo(a);
        validarAstroRepetido(a);
        listaAstros.add(a);
    }

    private void validarAstroNulo(Astro a) {
        if (a == null) {
            throw new AstroNuloException();
        }
    }

    private void validarAstroRepetido(Astro astro) {
        for (Astro a : listaAstros) {
            if (a.equals(astro)) {
                throw new AstroExistenteException();
            }
        }
    }

    public void mostrarAstros() {
        for (Astro a : listaAstros) {
            System.out.println(a.toString());
        }
    }

    public void generarCamposMagneticos() {
        for (Astro a : listaAstros) {
            try {
                if (a instanceof GeneradorDeCampo generador) {
                    generador.generarCampoMagnetico();
                } else {
                    throw new NoGeneradorException();
                }
            } catch (NoGeneradorException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public void modificarOrbitas() {
        for (Astro a : listaAstros) {
            try {
                if (a instanceof ModificadorDeOrbita mod) {
                    mod.modificarOrbita();
                } else {
                    throw new NoModificadorOrbitasException();
                }
            } catch (NoModificadorOrbitasException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public ArrayList<Astro> filtrarPorTipoRadiacion(TipoRadiacion tipo) {
        ArrayList<Astro> nuevaLista = new ArrayList<>();
        for (Astro a : listaAstros) {
            if (a.getTipo() == tipo) {
                System.out.println(a.toString());
                nuevaLista.add(a);
            }
        }
        return nuevaLista;
    }

    public void filtrarPorTipoDeAstro(String tipoAstro) {
        for (Astro a : listaAstros) {
            if (a.getClass().getSimpleName().equalsIgnoreCase(tipoAstro)) {
                System.out.println(a.toString());
            }
        }
    }

}
