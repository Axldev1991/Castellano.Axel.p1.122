package castellano.axel.rec1.pkg122;

public class Estrella extends Astro implements GeneradorDeCampo, ModificadorDeOrbita {

    private double tempSuperficialK;

    public Estrella(String nombreIdentificador, String region, TipoRadiacion tipo, double tempSuperficialK) {
        super(nombreIdentificador, region, tipo);
        this.tempSuperficialK = tempSuperficialK;
    }

    public double getTempSuperficialK() {
        return tempSuperficialK;
    }

    @Override
    public void generarCampoMagnetico() {
        System.out.println("La ESTRELLA " + getNombreIdentificador() + " está generando un campo magnético.");
    }

    @Override
    public void modificarOrbita() {
        System.out.println("La ESTRELLA " + getNombreIdentificador() + " modifica su orbita.");
    }

    @Override
    public String toString() {
        String base = super.toString();

        StringBuilder sb = new StringBuilder(base);
        sb.insert(sb.length() - 1, ", tempSuperficialK=" + tempSuperficialK);

        return sb.toString();
    }

}
